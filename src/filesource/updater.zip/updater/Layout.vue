<template>
  <div class="app-wrapper" :class="classObj">
    <sidebar class="sidebar-container"></sidebar>
    <div class="main-container">
      <navbar></navbar>
      <app-main></app-main>
      <button @click="updateApp" style="width:100px;height: 40px;">更新</button>
      <Update :show.sync="show" :percent="percent"></Update>
    </div>
  </div>
</template>

<script>
import { Navbar, Sidebar, AppMain, Update } from './components'
import ResizeMixin from './mixin/ResizeHandler'

export default {
  name: 'layout',
  components: {
    Navbar,
    Sidebar,
    AppMain,
    Update
  },
  data() {
    return {
      percent: 0,
      show: false
    }
  },
  mounted() {
    // this.handleAutoUpdate()
  },
  methods: {
    updateApp() {
      this.$electron.ipcRenderer.send('checkForUpdate', 'asdad')
    },
    handleAutoUpdate() {
      this.$electron.ipcRenderer.on('downloadProgress', (event, data) => {
        this.percent = (data.percent).toFixed(2)
        if (data.percent >= 100) {
          this.show = false
        }
      })

      /**
       * 主进程返回的检测状态
       */
      this.$electron.ipcRenderer.on('message', (event, data) => {
        switch (data.status) {
          case -1:
            this.$Message.error(data.msg)
            break
          case 0:
            this.$Message.loading(data.msg)
            break
          case 1:
            this.show = true
            break
        }
      })
    }
  },
  mixins: [ResizeMixin],
  computed: {
    sidebar() {
      return this.$store.state.app.sidebar
    },
    device() {
      return this.$store.state.app.device
    },
    classObj() {
      return {
        hideSidebar: !this.sidebar.opened,
        withoutAnimation: this.sidebar.withoutAnimation,
        mobile: this.device === 'mobile'
      }
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  @import "../../styles/mixin.scss";
  .app-wrapper {
    @include clearfix;
    position: relative;
    height: 100%;
    width: 100%;
  }
</style>
